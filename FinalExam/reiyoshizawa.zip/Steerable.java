package FinalExam;

/**
 * @author Rei Yoshizawa
 */

interface Steerable {

    void accelerate();
    void steerLeft();
    void steerRight();

}
